/*Integrantes:
Walter Alexander Cruz 20673
Christopher García 20541
Alejandro Pallais 20093
Maria Isabel Solano 20504
Gabriel Vicente 20498
*/
/*Instanciamiento de los .util necesarios*/
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Random;

class Actividades{
	//intanciamiento de array que guarda strings
	private ArrayList<String> store;
	
	public Actividades(){
		store = new ArrayList<String>();
	}
	//metodos para controlar el array
	public int limpiar(){
		store.clear();
		return store.size();
	}
	
	public void agregar(String a){
		store.add(a);
	}

	public void quitar(){
		store.remove(0);
	}
	
	public String obtener(int a){
		return store.get(a);
	}

	public int cantidad(){
		return store.size();
	}
}