/******************************
 clase método
 *******************************/

import java.text.DecimalFormat;
import java.io.*;
import javax.swing.JOptionPane;

class metodo{
	public metodo(){
		
	}
	public void escribir(String info){
		
		File f;
		FileWriter w;
		BufferedWriter bw;
		PrintWriter wr;
		
		try{

			w = new FileWriter("registro.txt",true);
			wr = new PrintWriter(w);
			

			wr.append(info);
			
			wr.close();
			w.close();
			
		}catch(Exception e){
			JOptionPane.showMessageDialog(null,"ha sucedido un error"+e);
			
		}
		
	}
	
	public String leerTxt(String direccion){ //direccion del archivo
        
        String texto = "";
        
        try{
            BufferedReader bf = new BufferedReader(new FileReader(direccion));
            String temp = "";
            String bfRead;
            while((bfRead = bf.readLine()) != null){ 
                //haz el ciclo, mientras bfRead tiene datos
                temp = temp + bfRead; //guardado el texto del archivo
            }
            
            texto = temp;
            
        }catch(Exception e){ 
            System.err.println("No se encontro archivo");
        }
        
        return texto;
        
    }
	
	public void leerv2(){
		File archivo;
		FileReader fr;
		BufferedReader br;
		
		try{
			archivo = new File("registro.txt");
			fr = new FileReader(archivo);
			br = new BufferedReader(fr);
			
			String linea;
			
			while((linea=br.readLine())!=null ){
				
				System.out.println(linea);
				
			}
			
			br.close();
			fr.close();
		}catch(Exception e){
			JOptionPane.showMessageDialog(null,"Hubo un error leyendo el archivo");
			
		}
	}
}