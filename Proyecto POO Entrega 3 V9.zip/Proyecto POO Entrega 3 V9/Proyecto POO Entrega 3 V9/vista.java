/******************************
 clase vista
 *******************************/

import java.util.Scanner; //Para obtener las respuestas de los usuarios

//clase vista que contrla la interacción con el usuario
class vista{
	Scanner scan = new Scanner(System.in);
	//Random aleatorio = new Random();
	public vista(){
	}
	
	public String inicial_nombre(){
		System.out.println("\n_______________________________________________________________________________");
		System.out.println("\n____________________Registro de actividades que gastan agua____________________\n");
		System.out.println("_______________________________________________________________________________\n\n");
		
		String usuario_inicial = "";
		boolean verificador=false;
		do{
			System.out.println("	Ingresa el nombre de tu usuario inicial\n");
			usuario_inicial = scan.nextLine();
			if(usuario_inicial.equals("")){
				System.out.println("el nombre del  usuario no puede ser vacio");
			}else{
				verificador=true;
			}
		}while(verificador==false);
		
		return usuario_inicial;
		
	}
	
	public String inicial_actividad(){
		boolean verificador=false;
		String actividad_inicial = "";
		do{
			System.out.println("	Ingresa una actividad que utilice agua en tu rutina diaria");
			actividad_inicial = scan.nextLine();
		if(actividad_inicial.equals("")){
				System.out.println("tiene que ingresar algo");
			}else{
				verificador=true;
			}
		}while(verificador==false);
			
		System.out.println("	Presiona ENTER para continuar....\n");
		scan.nextLine();
		
		return actividad_inicial;
	}
	
	public int menu_opcion(String usuario_inicial,int day){
		boolean verificador=false;
		int opcion=-1;
		do{
			System.out.println("\n_______________________________________________________________________________");
			System.out.println("\n_____________________ 	Bienvenido "+usuario_inicial+"!	 _____________________\n");
			System.out.println("\n_____________________Ingrese la opcion que desea realizar_____________________\n");
			System.out.println("\n	Dia: "+day);
			
	
			System.out.println("	1.  Ingresar un registro de actividades");
			System.out.println("	2.  Ver registro.");
			System.out.println("	3.  Agregar actividad/usuario.");
			System.out.println("	4.  Pasar dia.");
			System.out.println("	5.  Salir");
			

			try{
			
				opcion = Integer.parseInt(scan.nextLine());

				
			}catch(Exception e){
				System.out.println("ese no es un numero entero");
			}
			
			if(opcion<1||opcion>5){
				System.out.println("esa no es una opcion");
			}else{
				verificador=true;
			}
		}while(verificador==false);
		
			return opcion;
	}
	
	public int num_user(Persona personas){
		
		int persona_registro=-1;
		boolean verificador=false;
		do{
			System.out.println("	Ingresa el numero del usuario que deseas agregar en el registro.");
			for(int i =0;i<personas.cantidad();i++){
				System.out.println("	"+(i+1)+". " +personas.obtener(i));
			}
			try{
				persona_registro = Integer.parseInt(scan.nextLine());
			}catch(Exception e){
				System.out.println("ese no es un numero entero");
			}
			if(persona_registro<1||persona_registro>personas.cantidad()){
				System.out.println("esa no es una opccion");
			}else{
				verificador=true;
			}
		}while(verificador==false);
		return persona_registro;
	}
	
	public int num_act(Actividades actividad){
		int actividad_registro=-1;
		boolean verificador=false;
		do{
			System.out.println("	Ingresa el numero de la actividad que realizo el usuario");
			for(int i =0;i<actividad.cantidad();i++){
				System.out.println("	"+(i+1)+". " +actividad.obtener(i));
			}
			try{
				actividad_registro = Integer.parseInt(scan.nextLine());
			}catch(Exception e){
				System.out.println("ese no es un numero entero");
			}
			if(actividad_registro<1||actividad_registro>actividad.cantidad()){
				System.out.println("esa no es una opccion");
			}else{
				verificador=true;
			}
		}while(verificador==false);
			return actividad_registro;
	}
	
	public int num_time(){
		int tiempo_registro=-1;
		boolean verificador=false;
		do{
			System.out.println("	Ingresa la cantidad de tiempo que se realizo la actividad");
			try{
				tiempo_registro = Integer.parseInt(scan.nextLine());
			}catch(Exception e){
				System.out.println("tiene que ser un numero entero");
			}
			if(tiempo_registro<0){
				System.out.println("no puede ser negativo");
			}else{
				verificador=true;
			}
		}while(verificador==false);
			return tiempo_registro;
	}
	
	public void Registro_ver( int tiempo_total){
			System.out.println("	Registro actual de las actividades");

			System.out.println("\n	Tiempo total del uso de agua "+tiempo_total+" ;Litros en agua gastados(aproximacion): "+tiempo_total*150+"L");
	}
	
	public void dia_ver(int day){
		System.out.println("	Bienvenido al dia: "+day);
	}

	public int menu_opcion_agregar(){
		int eleccion_2 = 0;
		boolean verificador=false;
		do{
			System.out.println("	Ingresa a que caracteristica desea agregar un elemento");
			System.out.println("	1. Usuario");
			System.out.println("	2. Actividades");
			try{
				eleccion_2 = Integer.parseInt(scan.nextLine());
			}catch(Exception e){
				System.out.println("ese no es un numero entero");
			}
			if(eleccion_2<1||eleccion_2>2){
				System.out.println("esa no es una opccion");
			}else{
				verificador=true;
			}
		}while(verificador==false);
			return eleccion_2;
	}
	
	public String menu_opcion_agregar1(){
		boolean verificador=false;
		String name = "";
		do{
			System.out.println("	Ingresa el nombre de otro usuario\n");
			name = scan.nextLine();
			if(name.equals("")){
				System.out.println("el nombre del  usuario no puede ser vacio");
			}else{
				verificador=true;
			}
		}while(verificador==false);
			return name;
	}
	
	public String menu_opcion_agregar2(){
			
		boolean verificador=false;
		String activity = "";
		do{
			System.out.println("	Ingresa la actividad que desea agregar");
			activity = scan.nextLine();
			if(activity.equals("")){
				System.out.println("tiene que ingresar algo");
			}else{
				verificador=true;
			}
		}while(verificador==false);
			return activity;
	}
	
}