/******************************
 clase método
 *******************************/

import java.text.DecimalFormat;
import java.io.*;
import javax.swing.JOptionPane;

class metodo{
	public metodo(){
		
	}
	public void escribir(int num,String info){
		if(num == 1){
			File f;
			FileWriter w;
			BufferedWriter bw;
			PrintWriter wr;
		
			try{

				w = new FileWriter("registro.txt",true);
				wr = new PrintWriter(w);
			

				wr.append(info);
			
				wr.close();
				w.close();
			
			}catch(Exception e){
				JOptionPane.showMessageDialog(null,"ha sucedido un error"+e);
			
			}
			
		}else if(num == 2){
			File f;
			FileWriter w;
			BufferedWriter bw;
			PrintWriter wr;
		
			try{

				w = new FileWriter("registro_minutos.txt",true);
				wr = new PrintWriter(w);
			

				wr.append(info);
			
				wr.close();
				w.close();
			
			}catch(Exception e){
				JOptionPane.showMessageDialog(null,"ha sucedido un error"+e);
			
			}
			
		}else if(num == 3){
			File f;
			FileWriter w;
			BufferedWriter bw;
			PrintWriter wr;
		
			try{

				w = new FileWriter("actividad_shower.txt",true);
				wr = new PrintWriter(w);
			

				wr.append(info);
			
				wr.close();
				w.close();
			
			}catch(Exception e){
				JOptionPane.showMessageDialog(null,"ha sucedido un error"+e);
			
			}
			
		}else if(num == 4){
			File f;
			FileWriter w;
			BufferedWriter bw;
			PrintWriter wr;
		
			try{

				w = new FileWriter("actividad_lavar.txt",true);
				wr = new PrintWriter(w);
			

				wr.append(info);
			
				wr.close();
				w.close();
			
			}catch(Exception e){
				JOptionPane.showMessageDialog(null,"ha sucedido un error"+e);
			
			}
			
		}else if(num == 5){
			File f;
			FileWriter w;
			BufferedWriter bw;
			PrintWriter wr;
		
			try{

				w = new FileWriter("actividad_extra.txt",true);
				wr = new PrintWriter(w);
			

				wr.append(info);
			
				wr.close();
				w.close();
			
			}catch(Exception e){
				JOptionPane.showMessageDialog(null,"ha sucedido un error"+e);
			
			}
			
		}
	}
	
	public String leerTxt(String direccion){ //direccion del archivo
        
        String texto = "";
        
        try{
            BufferedReader bf = new BufferedReader(new FileReader(direccion));
            String temp = "";
            String bfRead;
            while((bfRead = bf.readLine()) != null){ 
                //haz el ciclo, mientras bfRead tiene datos
                temp = temp + bfRead; //guardado el texto del archivo
            }
            
            texto = temp;
            
        }catch(Exception e){ 
            System.err.println("No se encontro archivo");
        }
        
        return texto;
        
    }
	
	public void leerv2(){
		File archivo;
		FileReader fr;
		BufferedReader br;
		
		try{
			archivo = new File("registro.txt");
			fr = new FileReader(archivo);
			br = new BufferedReader(fr);
			
			String linea;
			
			while((linea=br.readLine())!=null ){
				
				System.out.println(linea);
				
			}
			
			br.close();
			fr.close();
		}catch(Exception e){
			JOptionPane.showMessageDialog(null,"Hubo un error leyendo el archivo");
			
		}
	}
}