package proyecto2020_09_3;
/******************************
 clase método
 *******************************/

import java.text.DecimalFormat;
import java.io.*;
import javax.swing.JOptionPane;
import java.util.ArrayList;

class metodo{
	
	
	public metodo(){
		
	}
	public void escribir(int num,String info){
		if(num == 1){
			File f;
			FileWriter w;
			BufferedWriter bw;
			PrintWriter wr;
		
			try{

				w = new FileWriter("registro.txt",true);
				wr = new PrintWriter(w);
			

				wr.append(info);
			
				wr.close();
				w.close();
			
			}catch(Exception e){
				JOptionPane.showMessageDialog(null,"ha sucedido un error"+e);
			
			}
			
		}else if(num == 2){
			File f;
			FileWriter w;
			BufferedWriter bw;
			PrintWriter wr;
		
			try{

				w = new FileWriter("registro_minutos.txt",true);
				wr = new PrintWriter(w);
			

				wr.append(info);
			
				wr.close();
				w.close();
			
			}catch(Exception e){
				JOptionPane.showMessageDialog(null,"ha sucedido un error"+e);
			
			}
			
		}else if(num == 3){
			File f;
			FileWriter w;
			BufferedWriter bw;
			PrintWriter wr;
		
			try{

				w = new FileWriter("actividad_shower.txt",true);
				wr = new PrintWriter(w);
			

				wr.append(info);
			
				wr.close();
				w.close();
			
			}catch(Exception e){
				JOptionPane.showMessageDialog(null,"ha sucedido un error"+e);
			
			}
			
		}else if(num == 4){
			File f;
			FileWriter w;
			BufferedWriter bw;
			PrintWriter wr;
		
			try{

				w = new FileWriter("actividad_lavar.txt",true);
				wr = new PrintWriter(w);
			

				wr.append(info);
			
				wr.close();
				w.close();
			
			}catch(Exception e){
				JOptionPane.showMessageDialog(null,"ha sucedido un error"+e);
			
			}
			
		}else if(num == 5){
			File f;
			FileWriter w;
			BufferedWriter bw;
			PrintWriter wr;
		
			try{

				w = new FileWriter("actividad_extra.txt",true);
				wr = new PrintWriter(w);
			

				wr.append(info);
			
				wr.close();
				w.close();
			
			}catch(Exception e){
				JOptionPane.showMessageDialog(null,"ha sucedido un error"+e);
			
			}
			
		}
	}
	
	public String leerTxt(String direccion){ //direccion del archivo
        
        String texto = "";
        
        try{
            BufferedReader bf = new BufferedReader(new FileReader(direccion));
            String temp = "";
            String bfRead;
            while((bfRead = bf.readLine()) != null){ 
                //haz el ciclo, mientras bfRead tiene datos
                temp = temp + bfRead; //guardado el texto del archivo
            }
            
            texto = temp;
            
        }catch(Exception e){ 
            System.err.println("No se encontro archivo");
        }
        
        return texto;
        
    }
	
	public String[] leerv2(){
		File archivo;
		FileReader fr;
		BufferedReader br;
                ArrayList<String> store=new ArrayList<String>();
		int contador=0;
			String [] imprimir;
		try{
			archivo = new File("registro.txt");
			fr = new FileReader(archivo);
			br = new BufferedReader(fr);
			
			String linea;
                        
			while((linea=br.readLine())!=null ){
                            store.add(linea);
                            contador++;
				
			}
                        
                        
                        
			br.close();
			fr.close();
		}catch(Exception e){
			JOptionPane.showMessageDialog(null,"Hubo un error leyendo el archivo");
			
		}
                
                imprimir=new String[contador];
                for(int i=0;i<contador;i++){
                    imprimir[i]=store.get(i);
                }
                return imprimir;
	}

	public ArrayList<Integer> leerV3(int doc){
		//Devuelve un Array de ints para utilizar con las estadísticas
		ArrayList<Integer> Data = new ArrayList<Integer>();
		File archivo;
		FileReader fr;
		BufferedReader br;

		try{
			archivo = new File("registro.txt"); //Solo para iniciar la variable
			//Daterminar el archivo de donde viene la información
			if (doc == 1) {
				//Se obtienen los datos de shower
				archivo = new File("actividad_shower.txt");
			}
			else if (doc == 2){
				//Se obtienen los datos de lavar
				archivo = new File("actividad_lavar.txt");
			}
			else if (doc == 3){
				//Se obtienen los datos de extra
				archivo = new File("actividad_extra.txt");
			}


			fr = new FileReader(archivo);
			br = new BufferedReader(fr);

			String dato; //Cada línea del archivo es un dato

			while((dato = br.readLine())!=null ){
				int trans = Integer.parseInt(dato);// Se transforma de Sting a Int
				Data.add(trans);
			}
			br.close();
			fr.close();
		}
		catch(Exception e){
			JOptionPane.showMessageDialog(null,"Hubo un error leyendo el archivo");

		}
		return Data;
	}
	
	/*public boolean Salir(){
		
		boolean Estado = false;
		int Salidas = vis.Salir();
		if (Salidas == 1){
			Estado = true;
		} else if (Salidas == 0){
			Estado = false;
		} else {
			System.out.println("\nHa ocurrido un error");
			System.out.println("Ingresaste una opcion que no existe\n");
		}
		
		return Estado;
	}*/
	
}