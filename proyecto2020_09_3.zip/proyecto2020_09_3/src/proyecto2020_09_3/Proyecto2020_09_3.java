package proyecto2020_09_3;

import java.util.ArrayList;

/**
 *
 * @author Alejandro Pallais
 */
public class Proyecto2020_09_3 {

    /**
     * @param args the command line arguments
     */
    
    public static metodo m = new metodo();
    
    public static Persona personas = new Persona();
    public static Actividades actividad = new Actividades();
    
   
    public static void main(String[] args) {
        // TODO code application logic here
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new proyecto2020_09_3interface(personas,m,actividad).setVisible(true);
            }
        });
    }
    
}
