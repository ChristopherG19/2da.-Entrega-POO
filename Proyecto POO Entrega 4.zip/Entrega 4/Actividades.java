
/******************************
 clase Actividades
 *******************************/

import java.util.ArrayList;

class Actividades{
	//intanciamiento de array que guarda strings
	private ArrayList<String> store;
	
	public Actividades(){
		store = new ArrayList<String>();
	}
	//metodos para controlar el array
	public int limpiar(){
		store.clear();
		return store.size();
		//metodo para eliminar todas las actividades
	}
	
	public void agregar(String a){
		store.add(a);
		//método para agregar actividades
	}

	public void quitar(){
		store.remove(0);
		//método para eliminar actividades
	}
	
	public String obtener(int a){
		return store.get(a);
		//método para encontrar una actividades específica
	}

	public int cantidad(){
		return store.size();
		//método para saber el largo del array de actividades
	}
}