

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Random;
import java.text.DecimalFormat;

class driver{
	public static void main(String[] args){
		//intancia de Scanner que nos permite interactuar con el usuario y Random para uso de algunas opciones del menú:
		Scanner scan = new Scanner(System.in);
		Random aleatorio = new Random();
		Persona personas = new Persona();
		Actividades actividad = new Actividades();
		Registro registro = new Registro();
		
		int ciclo = 0;
		int day = 1;
		int tiempo_total=0;

		
		//mensaje de bienvenida del programa.
		System.out.println("\n_______________________________________________________________________________");
		System.out.println("\n____________________Registro de actividades que gastan agua____________________\n");
		System.out.println("_______________________________________________________________________________\n\n");
		
		System.out.println("	Ingresa el nombre de tu usuario inicial\n");
		String usuario_inicial = scan.nextLine();
		personas.agregar(usuario_inicial);

		System.out.println("	Ingresa una actividad que utilice agua en tu rutina diaria");
		String actividad_inicial = scan.nextLine();
		actividad.agregar(actividad_inicial);
			
		System.out.println("	Presiona ENTER para continuar....\n");
		scan.nextLine();

		//inicio de ciclo que solo tiene dos opciones
		while (ciclo != 8){
			
			System.out.println("\n_______________________________________________________________________________");
			System.out.println("\n_____________________ 	Bienvenido "+usuario_inicial+"!	 _____________________\n");
			System.out.println("\n_____________________Ingrese la opcion que desea realizar_____________________\n");
			System.out.println("\n	Dia: "+day);
			
	
			System.out.println("	1.  Ingresar un registro de actividades");
			System.out.println("	2.  Ver registro.");
			System.out.println("	3.  Agregar actividad/usuario.");
			System.out.println("	4.  Pasar dia.");
			System.out.println("	5.  Salir");
			


			
			int opcion = scan.nextInt();
			scan.nextLine();

			if (opcion == 1){
				System.out.println("	Ingresa el numero del usuario que deseas agregar en el registro.");
				for(int i =0;i<personas.cantidad();i++){
					System.out.println("	"+(i+1)+". " +personas.obtener(i));
				}
				int persona_registro = scan.nextInt();
				scan.nextLine();
				
				System.out.println("	Ingresa el numero de la actividad que realizo el usuario");
				for(int i =0;i<actividad.cantidad();i++){
					System.out.println("	"+(i+1)+". " +actividad.obtener(i));
				}
				int actividad_registro = scan.nextInt();
				scan.nextLine();			

				System.out.println("	Ingresa la cantidad de tiempo que se realizo la actividad");
				int tiempo_registro = scan.nextInt();
				scan.nextLine();
				tiempo_total = tiempo_total+tiempo_registro;


				registro.agregar("	Persona:"+personas.obtener(persona_registro-1)+" Actividad:"+actividad.obtener(actividad_registro-1)+" Tiempo invertido:"+tiempo_registro+" min");
				
			} else if (opcion == 2){
				System.out.println("	Registro actual de las actividades");
				for(int i =0;i<registro.cantidad();i++){
					System.out.println(registro.obtener(i));
				}
				System.out.println("\n	Tiempo total del uso de agua "+tiempo_total+" ;Litros en agua gastados(aproximacion): "+tiempo_total*150+"L");
			} else if (opcion == 3){
				System.out.println("	Ingresa a que caracteristica desea agregar un elemento");
				System.out.println("	1. Usuario");
				System.out.println("	2. Actividades");
				
				int eleccion_2 = scan.nextInt();
				scan.nextLine();
				if(eleccion_2==1){
					System.out.println("	Ingresa el nombre de otro usuario");
					String name = scan.nextLine();
					personas.agregar(name);
				} else 	if(eleccion_2==2){
					System.out.println("	Ingresa la actividad que desea agregar");
					String activity = scan.nextLine();
					actividad.agregar(activity);
				}
			} else if (opcion == 4){
				day++;
				System.out.println("	Bienvenido al dia: "+day);
			}	else if (opcion == 5){
				ciclo = 8;	
			} else if (opcion<1||opcion>6){

				System.out.println("\n-----------Has ingresado una opcion invalida, intenta otra vez.-----------\n");
			}
			
		}
	}
}