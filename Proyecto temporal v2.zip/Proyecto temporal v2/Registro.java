
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Random;

class Registro{
	private ArrayList<String> store;
	
	public Registro(){
		store = new ArrayList<String>();
	}
	
	public int limpiar(){
		store.clear();
		return store.size();
	}
	
	public void agregar(String a){
		store.add(a);
	}

	public void quitar(){
		store.remove(0);
	}
	
	public String	obtener(int a){
		return store.get(a);
	}

	public int cantidad(){
		return store.size();
	}
}