
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Random;

class vista{
	Scanner scan = new Scanner(System.in);
	Random aleatorio = new Random();
	public vista(){
	}
	
	public String inicial_nombre(){
		System.out.println("\n_______________________________________________________________________________");
		System.out.println("\n____________________Registro de actividades que gastan agua____________________\n");
		System.out.println("_______________________________________________________________________________\n\n");
		
		System.out.println("	Ingresa el nombre de tu usuario inicial\n");
		String usuario_inicial = scan.nextLine();
		
		return usuario_inicial;
		
	}
	
	public String inicial_actividad(){
				System.out.println("	Ingresa una actividad que utilice agua en tu rutina diaria");
		String actividad_inicial = scan.nextLine();
			
		System.out.println("	Presiona ENTER para continuar....\n");
		scan.nextLine();
		
		return actividad_inicial;
	}
	
	public int menu_opcion(String usuario_inicial,int day){
			System.out.println("\n_______________________________________________________________________________");
			System.out.println("\n_____________________ 	Bienvenido "+usuario_inicial+"!	 _____________________\n");
			System.out.println("\n_____________________Ingrese la opcion que desea realizar_____________________\n");
			System.out.println("\n	Dia: "+day);
			
	
			System.out.println("	1.  Ingresar un registro de actividades");
			System.out.println("	2.  Ver registro.");
			System.out.println("	3.  Agregar actividad/usuario.");
			System.out.println("	4.  Pasar dia.");
			System.out.println("	5.  Salir");
			


			
			int opcion = scan.nextInt();
			scan.nextLine();
			
			return opcion;
	}
	
	public int num_user(Persona personas){
			System.out.println("	Ingresa el numero del usuario que deseas agregar en el registro.");
			for(int i =0;i<personas.cantidad();i++){
				System.out.println("	"+(i+1)+". " +personas.obtener(i));
			}
			int persona_registro = scan.nextInt();
			scan.nextLine();
			return persona_registro;
	}
	
	public int num_act(Actividades actividad){
			System.out.println("	Ingresa el numero de la actividad que realizo el usuario");
			for(int i =0;i<actividad.cantidad();i++){
				System.out.println("	"+(i+1)+". " +actividad.obtener(i));
			}
			int actividad_registro = scan.nextInt();
			scan.nextLine();	
			return actividad_registro;
	}
	
	public int num_time(){
			System.out.println("	Ingresa la cantidad de tiempo que se realizo la actividad");
			int tiempo_registro = scan.nextInt();
			scan.nextLine();
			return tiempo_registro;
	}
	
	public void Registro_ver(Registro registro, int tiempo_total){
			System.out.println("	Registro actual de las actividades");
			for(int i =0;i<registro.cantidad();i++){
			System.out.println(registro.obtener(i));
			}
			System.out.println("\n	Tiempo total del uso de agua "+tiempo_total+" ;Litros en agua gastados(aproximacion): "+tiempo_total*150+"L");
	}
	
	public void dia_ver(int day){
		System.out.println("	Bienvenido al dia: "+day);
	}

	public int menu_opcion_agregar(){
			System.out.println("	Ingresa a que caracteristica desea agregar un elemento");
			System.out.println("	1. Usuario");
			System.out.println("	2. Actividades");
			
			int eleccion_2 = scan.nextInt();
			scan.nextLine();
			return eleccion_2;
	}
	
	public String menu_opcion_agregar1(){
			System.out.println("	Ingresa el nombre de otro usuario");
			String name = scan.nextLine();
			return name;
	}
	
	public String menu_opcion_agregar2(){
			System.out.println("	Ingresa la actividad que desea agregar");
			String activity = scan.nextLine();
			return activity;
	}
	
}