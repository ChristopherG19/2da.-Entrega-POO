

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Random;
import java.text.DecimalFormat;

class driver{
	public static void main(String[] args){
		//intancia de Scanner que nos permite interactuar con el usuario y Random para uso de algunas opciones del menú:
		Scanner scan = new Scanner(System.in);
		Random aleatorio = new Random();
		Persona personas = new Persona();
		Actividades actividad = new Actividades();
		Registro registro = new Registro();
		vista view = new vista();
		
		int ciclo = 0;
		int day = 1;
		int tiempo_total=0;

		
		//mensaje de bienvenida del programa.

		String usuario_inicial = view.inicial_nombre();
		personas.agregar(usuario_inicial);


		String actividad_inicial = view.inicial_actividad();
		actividad.agregar(actividad_inicial);
		
		//inicio de ciclo que solo tiene dos opciones
		while (ciclo != 8){
			
			int opcion = view.menu_opcion(usuario_inicial,day);

			if (opcion == 1){

				int persona_registro = view.num_user(personas);
				
				int actividad_registro = view.num_act(actividad) ;

				int tiempo_registro = view.num_time();

				tiempo_total = tiempo_total+tiempo_registro;

				registro.agregar("	Persona:"+personas.obtener(persona_registro-1)+" Actividad:"+actividad.obtener(actividad_registro-1)+" Tiempo invertido:"+tiempo_registro+" min");
				
			} else if (opcion == 2){
				view.Registro_ver(registro,tiempo_total);
			} else if (opcion == 3){
				int eleccion_2 = view.menu_opcion_agregar();
				if(eleccion_2==1){
					String name = view.menu_opcion_agregar1();
					personas.agregar(name);
				} else 	if(eleccion_2==2){
					String activity = view.menu_opcion_agregar2();
					actividad.agregar(activity);
				}
			} else if (opcion == 4){
				day++;
				view.dia_ver(day);
			}	else if (opcion == 5){
				ciclo = 8;	
			} else if (opcion<1||opcion>6){

				System.out.println("\n-----------Has ingresado una opcion invalida, intenta otra vez.-----------\n");
			}
			
		}
	}
}